﻿SPACE HAVEN LIVE TRAINER v0.8.1
Author: Luca Cococcioni

HOTFIX v0.8.1
- Fix installer PowerShell 5.1 parser error.
- Fix ProgramFiles(x86) Steam detection.
- Improved Steam library detection.
- GUI and trainer functions are otherwise unchanged from v0.8.0.

INSTALL
1. Extract this ZIP.
2. Run INSTALLA_MOD.bat normally.
3. If Windows denies writing to the Steam folder, then run only
   INSTALLA_MOD.bat as administrator.
4. Open the Mod Loader and verify v0.8.1.
5. Clear QuickLaunch cache.
6. Start Space Haven, load a game, then run AVVIA_GUI.bat.
