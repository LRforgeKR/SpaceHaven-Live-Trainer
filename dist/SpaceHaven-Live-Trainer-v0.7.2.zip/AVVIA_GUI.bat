@echo off
cd /d "%~dp0"
call "%~dp0SpaceHavenLiveTrainerGUI\AVVIA_GUI.bat"
