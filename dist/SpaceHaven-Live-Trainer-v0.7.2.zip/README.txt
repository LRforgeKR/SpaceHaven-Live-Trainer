SPACE HAVEN LIVE TRAINER v0.7.2
Author: Luca Cococcioni

REQUISITI
- Windows
- Space Haven
- Space Haven Mod Loader >= 0.10.0

INSTALLAZIONE RAPIDA
1. Estrai questo ZIP.
2. Esegui INSTALLA_MOD.bat.
3. Apri Mod Loader e verifica v0.7.2.
4. Esegui Clear QuickLaunch cache.
5. Avvia Space Haven dal Mod Loader e carica una partita.
6. Esegui AVVIA_GUI.bat.

INSTALLA_E_AVVIA_GUI.bat installa il mod e apre subito la GUI.
La GUI resta in attesa finche Space Haven + mod non sono attivi.

NOTA
La GUI non richiede privilegi amministratore.
Se Windows blocca la copia nella cartella Steam, esegui soltanto
INSTALLA_MOD.bat come amministratore.

Il progetto non include spacehaven.jar o altri file proprietari del gioco.
