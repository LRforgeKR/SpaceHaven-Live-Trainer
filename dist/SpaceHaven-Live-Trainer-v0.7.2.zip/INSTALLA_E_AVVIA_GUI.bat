@echo off
title Space Haven Live Trainer - Setup
cd /d "%~dp0"

powershell.exe -NoProfile -ExecutionPolicy Bypass -STA -File "%~dp0installer\Install-Mod.ps1"
if errorlevel 1 (
  echo.
  echo Installazione non completata.
  pause
  exit /b 1
)

echo.
echo Il mod e installato.
echo Avvia Space Haven dal Mod Loader e carica una partita.
echo La GUI puo essere aperta adesso: restera in attesa finche il mod non risponde.
echo.
start "" "%~dp0SpaceHavenLiveTrainerGUI\AVVIA_GUI.bat"
